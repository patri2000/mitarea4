/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetoc;

import java.util.Scanner;

/**
 *
 * @author isabel
 */
public class Objetoc {
    int codigo;
    int adf;
    String marca;
    String discod;
    String ram;
    double precio;
    
    
    public Objetoc(){
    
}
    
    public Objetoc(int codigo, int adf, String marca, String discod, String ram, double precio){
        this.codigo= codigo;
        this.adf= adf;
        this.discod=discod;
        this.marca=marca;
        this.ram=ram;
        this.precio=precio;
        
    }
    
    public void mostrar(){
        System.out.println("\ningrese el codigo: "+codigo);
        System.out.println("ingrese el año de fabricacion: "+adf);
        System.out.println("ingrese la capacidad del disco duro"+discod);
        System.out.println("ingrese la marca de la computadora"+marca);
        System.out.println("ingrese la capacidad de la memoria RAM"+ram);
        System.out.println("ingrese el precio de la computadora"+precio);
    }
    
    
    

    public static void main(String[] args) {
        Objetoc pb=new Objetoc();
        pb.codigo=5891;
        pb.adf=2011;
        pb.discod="500GB";
        pb.marca="HP";
        pb.ram="4GB";
        pb.precio=500;
        pb.mostrar();
        
        Objetoc pb2=new Objetoc(1546, 2012, "100GB", "SONY", "5GB", 250);
        pb2.mostrar();
        
        
    }

    
    
}
